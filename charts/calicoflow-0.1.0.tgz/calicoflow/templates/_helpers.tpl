{{/*
Expand the name of the chart.
*/}}
{{- define "calicoflow.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "calicoflow.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "calicoflow.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "calicoflow.labels" -}}
helm.sh/chart: {{ include "calicoflow.chart" . }}
{{ include "calicoflow.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "calicoflow.selectorLabels" -}}
app.kubernetes.io/name: {{ include "calicoflow.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the namespace to deploy into.
*/}}
{{- define "calicoflow.namespace" -}}
{{- if .Values.namespaceOverride }}
{{- .Values.namespaceOverride }}
{{- else }}
{{- .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
Return the proper image repository.
*/}}
{{- define "calicoflow.image.repository" -}}
{{- .Values.image.repository | default "bougou/calicoflow" }}
{{- end }}

{{/*
Return the proper image tag.
*/}}
{{- define "calicoflow.image.tag" -}}
{{- .Values.image.tag | default .Chart.AppVersion | default "latest" }}
{{- end }}

{{/*
Return the full image reference.
*/}}
{{- define "calicoflow.image" -}}
{{- printf "%s:%s" (include "calicoflow.image.repository" .) (include "calicoflow.image.tag" .) }}
{{- end }}

{{/*
Return the service account name.
*/}}
{{- define "calicoflow.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "calicoflow.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Return the ConfigMap name.
*/}}
{{- define "calicoflow.configMapName" -}}
{{- include "calicoflow.fullname" . }}-config
{{- end }}
